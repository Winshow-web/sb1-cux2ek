import { useState } from 'react';
import type { BasicUser, Driver, Booking } from '../store';
import DriverCard from './DriverCard';
import BookingsList from './BookingsList';
import DashboardOverview from './dashboard/DashboardOverview';
import ActiveContracts from './dashboard/ActiveContracts';
import RouteSchedule from './dashboard/RouteSchedule';
import ChatList from './chat/ChatList';
import ChatWindow from './chat/ChatWindow';
import InvoiceList from './invoice/InvoiceList';
import ExpenseNotifications from './expenses/ExpenseNotifications';
import { Layout, ChevronDown } from 'lucide-react';

interface ClientDashboardProps {
  user: BasicUser;
  drivers: Driver[];
  bookings: Booking[];
  onBook: (driverUuid: string) => void;
}

export default function ClientDashboard({
  user,
  drivers,
  bookings,
  onBook,
}: ClientDashboardProps) {
  const [activeTab, setActiveTab] = useState<'overview' | 'drivers' | 'schedule' | 'invoices' | 'expenses'>('overview');
  const [selectedUser, setSelectedUser] = useState<BasicUser | null>(null);
  const [messages, setMessages] = useState<any[]>([]);

  const activeBookings = bookings.filter(b => b.status === 'confirmed');
  const completedBookings = bookings.filter(b => b.status === 'completed');
  const pendingBookings = bookings.filter(b => b.status === 'pending');

  const handleSendMessage = (content: string) => {
    if (selectedUser) {
      const newMessage = {
        id: Math.random().toString(),
        sender: user.uuid,
        receiver: selectedUser.uuid,
        content,
        createdAt: new Date().toISOString(),
        read: false,
      };
      setMessages([...messages, newMessage]);
    }
  };

  // Convert drivers to BasicUser format for ChatList
  const driverUsers: BasicUser[] = drivers.map(driver => ({
    uuid: driver.uuid,
    name: driver.name,
    email: driver.email,
    password: driver.password,
    accountType: driver.accountType,
  }));

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Dashboard Navigation */}
      <div className="mb-8 border-b border-gray-200">
        <nav className="flex space-x-8" aria-label="Tabs">
          {[
            { id: 'overview', name: 'Overview' },
            { id: 'drivers', name: 'Find Drivers' },
            { id: 'schedule', name: 'Schedule' },
            { id: 'invoices', name: 'Invoices' },
            { id: 'expenses', name: 'Expenses' },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as typeof activeTab)}
              className={`${
                activeTab === tab.id
                  ? 'border-indigo-500 text-indigo-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm`}
            >
              {tab.name}
            </button>
          ))}
        </nav>
      </div>

      <div className="flex">
        {/* Main Content */}
        <div className="flex-1 space-y-8">
          {activeTab === 'overview' && (
            <>
              <DashboardOverview
                activeBookings={activeBookings.length}
                completedBookings={completedBookings.length}
                pendingBookings={pendingBookings.length}
              />
              <ActiveContracts
                bookings={activeBookings}
                drivers={drivers}
              />
              
              {bookings.length > 0 && (
                <section id="bookings" className="mt-16">
                  <h2 className="text-2xl font-bold text-gray-900 mb-8">Recent Bookings</h2>
                  <BookingsList bookings={bookings.slice(0, 5)} drivers={drivers} />
                </section>
              )}
            </>
          )}

          {activeTab === 'drivers' && (
            <section id="drivers">
              <h2 className="text-2xl font-bold text-gray-900 mb-8">Available Drivers</h2>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
                {drivers
                  .filter((driver) => driver.availability)
                  .map((driver) => (
                    <DriverCard
                      key={driver.uuid}
                      driver={driver}
                      onBook={onBook}
                    />
                  ))}
              </div>
            </section>
          )}

          {activeTab === 'schedule' && (
            <RouteSchedule bookings={bookings} drivers={drivers} />
          )}

          {activeTab === 'invoices' && (
            <InvoiceList bookings={bookings} />
          )}

          {activeTab === 'expenses' && (
            <ExpenseNotifications drivers={drivers} />
          )}
        </div>

        {/* Chat Sidebar */}
        <div className="ml-8 flex flex-col space-y-4">
          <ChatList
            users={driverUsers}
            onSelectUser={setSelectedUser}
            currentUser={user}
          />
          {selectedUser && (
            <ChatWindow
              currentUser={user}
              otherUser={selectedUser}
              messages={messages.filter(
                m => (m.sender === user.uuid && m.receiver === selectedUser.uuid) ||
                     (m.sender === selectedUser.uuid && m.receiver === user.uuid)
              )}
              onSendMessage={handleSendMessage}
              onClose={() => setSelectedUser(null)}
            />
          )}
        </div>
      </div>
    </div>
  );
}